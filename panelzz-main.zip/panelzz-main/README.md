<div align=center>
 
# 🚀 DDoS Panel 🚀

# Liên hệ Zalo: 0965781640 Để lấy TK và MK Panel
# README ♥️
Thank you for using, please help me press a star button, thank you very much.<br>
One star = continuously updating multiple methods

# Info
- [x] Open Source
- [x] Powerful
- [x] Simple
- [x] Methods for Layer 4 and 7
- [x] Bypass (Cloudflare, OVH, NFO,...)  


# Setup
```sh
CentOS:
yum install git -y
yum install golang -y
yum install perl -y
yum install python2 -y
yum install python3 -y
yum install python3-pip -y
yum install nodejs -y
yum install npm -y

Debain, Ubuntu:

bash <(curl -Ls https://raw.githubusercontent.com/ht4g/panel/main/panel.sh)

How to use: 
- Recommended in shell of google, azure,...
- Using vps with high speed will be stronger

git clone https://github.com/ht4g/panel/
cd panel
npm i requests
npm i https-proxy-agent
npm i crypto-random-string
npm i events
npm i fs
npm i net
npm i cloudscraper
npm i request
npm i hcaptcha-solver
npm i randomstring
npm i cluster
npm i cloudflare-bypasser
pip install asciimatics
pip install pystyle
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
apt-get install ./google-chrome-stable_current_amd64.deb
ulimit -n 999999
chmod 777 *
python3 panel.py
```

# Credits
```sh
zxcr9999 (Reworked CnC and added some methods .-.)
SkyWtkhIsBack (Example Panel and L7 methods <3)
Empfaked (Layer 7 methods <3)
HyukIsBack (Layer 7 methods <3)
im-federal (Layer 4 and AMP methods <3)
R00tS3C (Layer 4 and AMP methods <3)
forkyyy (LAYER 7 METHODS <3)
Leeon123 (SPECIAL METHODS <3)
TheSpeedX (HTTP, SOCKS5, SOCK4 proxies <3)
```

# TOS:
```sh
Do not attack government pages (.gov/.gob), educational pages (.edu) or the United States Department of Defense (.mil), 
the creator is not responsible for the damage caused by the attacks. 
remember: you are responsible for the attacks since this tool was created for educational purposes
```

# CONTACT:
```sh
FB: fb.com/NTHHACKER
Zalo: zalo.me/hieudz3101
```
