apt-get update
sudo apt-get install golang -y
sudo apt-get install perl -y
sudo apt-get install python3 -y
sudo apt-get install python2 -y
sudo apt-get install python3-pip -y
sudo apt-get install nodejs -y
sudo apt-get install npm -y
git clone https://github.com/zain0x77/panelzz
cd panel
npm i requests
npm i https-proxy-agent
npm i crypto-random-string
npm i events
npm i fs
npm i net
npm i cloudscraper
npm i request
npm i hcaptcha-solver
npm i randomstring
npm i cluster
npm i cloudflare-bypasser
pip install asciimatics
pip install pystyle
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
apt-get install ./google-chrome-stable_current_amd64.deb
ulimit -n 999999
chmod 777 *
python3 panel.py
